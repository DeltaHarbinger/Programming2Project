Authors:
Brandon Chung
Phillip Newman


Extra Details:
-The header file containss all of the structs and some important global variables used. It is needed for compilation.
-Author Names and ID numbers are at the top of the C file
-The compiler used was Mgwin
-Commands exclusive to Windows are used in the program.
-To completely reset the program (get rid of all saved data) you may delete all files except for the header file, C file and exe.
